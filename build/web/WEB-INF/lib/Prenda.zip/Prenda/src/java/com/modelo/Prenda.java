/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.modelo;

/**
 *
 * @author ESTEBAN
 */
public class Prenda {
    private int idPrenda;
    private String ImagenPrenda;
    private String NombrePrenda;
    private String DescripcionPrenda;
    private String PrecioPrenda;
    private String EstadoPrenda;
    private String IdTipoPrendaFK;
    
    public Prenda() {
        
    }

    public int getIdPrenda() {
        return idPrenda;
    }

    public void setIdPrenda(int idPrenda) {
        this.idPrenda = idPrenda;
    }

    public String getImagenPrenda() {
        return ImagenPrenda;
    }

    public void setImagenPrenda(String ImagenPrenda) {
        this.ImagenPrenda = ImagenPrenda;
    }

    public String getNombrePrenda() {
        return NombrePrenda;
    }

    public void setNombrePrenda(String NombrePrenda) {
        this.NombrePrenda = NombrePrenda;
    }

    public String getDescripcionPrenda() {
        return DescripcionPrenda;
    }

    public void setDescripcionPrenda(String DescripcionPrenda) {
        this.DescripcionPrenda = DescripcionPrenda;
    }

    public String getPrecioPrenda() {
        return PrecioPrenda;
    }

    public void setPrecioPrenda(String PrecioPrenda) {
        this.PrecioPrenda = PrecioPrenda;
    }

    public String getEstadoPrenda() {
        return EstadoPrenda;
    }

    public void setEstadoPrenda(String EstadoPrenda) {
        this.EstadoPrenda = EstadoPrenda;
    }

    public String getIdTipoPrendaFK() {
        return IdTipoPrendaFK;
    }

    public void setIdTipoPrendaFK(String IdTipoPrendaFK) {
        this.IdTipoPrendaFK = IdTipoPrendaFK;
    }
    
    
}

