package com.modeloDAO;

import com.modelo.Prenda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PrendaDAO {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r = 0;

    public int agregar(Prenda p) {
        Conexion cn = new Conexion();
        String sql = "insert into prenda(ImagenPrenda, NombrePrenda, DescripcionPrenda, PrecioPrenda, EstadoPrenda)values(?,?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getImagenPrenda());
            ps.setString(2, p.getNombrePrenda());
            ps.setString(3, p.getDescripcionPrenda());
            ps.setString(4, p.getPrecioPrenda());
            ps.setString(5, p.getEstadoPrenda());
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return r;
    }

    public List<Prenda> listar() {
        Conexion cn = new Conexion();
        String sql = "select * from prenda";
        List<Prenda>lista=new ArrayList<>();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()) {
                Prenda p=new Prenda();
                p.setIdPrenda(rs.getInt(1));
                p.setImagenPrenda(rs.getString(2));
                p.setNombrePrenda(rs.getString(3));    
                p.setDescripcionPrenda(rs.getString(4));
                p.setPrecioPrenda(rs.getString(5));
                p.setEstadoPrenda(rs.getString(6));
                lista.add(p);
            }
        } catch (Exception e) {
        }
        return lista;
    }
}
